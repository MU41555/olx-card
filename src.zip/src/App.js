import logo from './logo.svg';
import './App.css';
import RecipeReviewCard from "./myComponents.js/myCard";
import myArr from './myComponents.js/myArray';

function App() {
  function Asd (val){
    return(
    <RecipeReviewCard 
    
      pName = {val.name}
      des = {val.discpriton}
      img = {val.imge}
      pri = {val.price}
      />
    );
  }
  return (
    <div className="App">
      {myArr.map(Asd)}
      

      
      
    </div>
  );
}

export default App;
